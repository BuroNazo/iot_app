import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class EspService {
  static const String setupIp = "192.168.4.1"; // Default ESP8266 AP IP
  String? _deviceIp;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _deviceIp = prefs.getString('device_ip');
  }

  Future<bool> provision(String ssid, String password) async {
    try {
      final response = await http.post(
        Uri.parse('http://$setupIp/provision'),
        body: {
          'ssid': ssid,
          'password': password,
        },
      ).timeout(const Duration(seconds: 10));

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  Future<bool> toggleRelay(bool status) async {
    if (_deviceIp == null) return false;
    
    final endpoint = status ? 'on' : 'off';
    try {
      final response = await http.get(
        Uri.parse('http://$_deviceIp/relay/$endpoint'),
      ).timeout(const Duration(seconds: 5));

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  Future<bool> getRelayStatus() async {
    if (_deviceIp == null) return false;

    try {
      final response = await http.get(
        Uri.parse('http://$_deviceIp/relay/status'),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['status'] == 'on';
      }
    } catch (_) {}
    return false;
  }

  void updateDeviceIp(String ip) async {
    _deviceIp = ip;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('device_ip', ip);
  }
}
