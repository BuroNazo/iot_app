import 'dart:async';
import 'package:wifi_scan/wifi_scan.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/wifi_network.dart';

class WifiService {
  final _networkInfo = NetworkInfo();

  /// Konum iznini açıkça iste (WiFi taraması için zorunlu)
  Future<bool> requestPermissions() async {
    // Konum izni
    final locationStatus = await Permission.location.request();
    if (!locationStatus.isGranted) return false;

    // Android 13+ için yakın cihaz WiFi izni
    final nearbyStatus = await Permission.nearbyWifiDevices.request();
    // nearbyWifiDevices bazı cihazlarda yoksa sorun çıkarmaz, devam edebiliriz

    return locationStatus.isGranted;
  }

  /// Tüm WiFi ağlarını tara ve döndür
  Future<List<WifiNetwork>> scan() async {
    try {
      // 1. Önce konum servisinin açık olup olmadığını kontrol et
      final serviceEnabled = await Permission.location.serviceStatus.isEnabled;
      if (!serviceEnabled) {
        // Konum servisi kapalı — boş döndür, UI kullanıcıyı bilgilendirir
        return [];
      }

      // 2. Yeni tarama başlatmayı dene (başlayamazsa eski sonuçlara bak)
      final canStart = await WiFiScan.instance.canStartScan();
      if (canStart == CanStartScan.yes) {
        await WiFiScan.instance.startScan();
        await Future.delayed(const Duration(seconds: 2));
      }

      // 3. Sonuçları al (yeni veya önbellek)
      final canGet = await WiFiScan.instance.canGetScannedResults(
        askPermissions: true,
      );
      if (canGet != CanGetScannedResults.yes) return [];

      final results = await WiFiScan.instance.getScannedResults();

      return results
          .map<WifiNetwork>(
            (res) => WifiNetwork(
              ssid: res.ssid,
              level: res.level,
              isSecure:
                  res.capabilities.contains('WPA') ||
                  res.capabilities.contains('WEP'),
            ),
          )
          .where((n) => n.ssid.isNotEmpty)
          .toSet() // Aynı SSID'yi tekrarlama
          .toList()
        ..sort((a, b) => b.level.compareTo(a.level)); // Sinyal gücüne göre sırala

    } catch (e) {
      return [];
    }
  }

  /// Android WiFi ayarlarını aç
  Future<void> openWifiSettings() async {
    final uri = Uri.parse('android.settings.WIFI_SETTINGS');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  /// Android Konum ayarlarını aç (GPS kapalıysa)
  Future<void> openLocationSettings() async {
    await openAppSettings();
  }

  /// Şu an bağlı olunan WiFi ağının SSID'sini döndürür
  Future<String?> getCurrentSSID() async {
    try {
      final ssid = await _networkInfo.getWifiName();
      return ssid?.replaceAll('"', '');
    } catch (_) {
      return null;
    }
  }

  /// Kullanıcının ESP_Setup'a bağlı olup olmadığını kontrol eder
  Future<bool> isConnectedToSetupAP() async {
    final ssid = await getCurrentSSID();
    return ssid == 'ESP_Setup';
  }

  void dispose() {}
}
