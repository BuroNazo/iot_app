import 'package:flutter/material.dart';
import 'screens/scan_screen.dart';
import 'screens/provision_screen.dart';
import 'screens/control_screen.dart';

void main() {
  runApp(const Esp01App());
}

class Esp01App extends StatelessWidget {
  const Esp01App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ESP-01 Controller',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        primaryColor: const Color(0xFF38BDF8),
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFF38BDF8),
          secondary: const Color(0xFF818CF8),
          surface: const Color(0xFF1E293B),
          onSurface: Colors.white,
        ),
        textTheme: const TextTheme(
          displayLarge: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          bodyLarge: TextStyle(color: Color(0xFF94A3B8)),
        ),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const ScanScreen(),
        '/provision': (context) => const ProvisionScreen(),
        '/control': (context) => const ControlScreen(),
      },
    );
  }
}
